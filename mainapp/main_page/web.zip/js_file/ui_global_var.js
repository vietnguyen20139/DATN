// get element btn submit, export to use var global
// export const txtPassword = document.querySelector('#btnSignin')
export const btnSignin = document.getElementById('btnSignin')

export const btnSignup = document.getElementById('btnSignup')
export const btnResetPass = document.getElementById('btnResetPass')
export const nameForPath = "";
